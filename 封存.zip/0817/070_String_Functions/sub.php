<?php
    $s="123123123123";

    $end=str_replace("1231","4",$s);

    echo $end;
?>