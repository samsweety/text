<?php

$a = 12;
$b = "34";

$result = $a + $b; // 46
// $result = $a . $b; // 1234
// $result = $a + intval($b);  // 46

echo $result;

?>