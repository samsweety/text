<?php
$a = 010;  // 8
$b = 0xA;  // 10
$c = 2;    // 2
print $a + $b + $c;
?>
