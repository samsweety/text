<?php

$obj = new CAnimal(10);
$obj->makeNoise();
echo "<hr>";
// $obj->weight = 10;  
// // 如果是 $obj->weight = -10; 呢
$obj->getWeight();
$obj->setWeight(-1);
$obj->setWeight(20);
$obj->getWeight();


class CAnimal{

    private $weight;

    function __construct($w){ 
        $this->weight=$w;
    }
    function __destruct(){
        echo "eater of the world";
    }
    
    public function setWeight($w){
        if($w>0){
            $this->weight=$w;
        }
        else
            echo "Enter value must greater than zero:".$w."<br>";

    }

    public function getWeight(){
        echo $this->weight."<br>";
    }
	
	public function makeNoise()
	{
        echo "CAnimal: makeNoise";
	}
}

?>