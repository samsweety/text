<?php


class CTest{
    function hello(){
        echo "hello";
    }
}

CTest::hello();


?>