<?php
	$a = 100;
	if ($a > 0) {
		echo '$a is positive.';
	}
?>