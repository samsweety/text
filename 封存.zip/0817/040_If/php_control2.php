<?php
	$a = -5;
	if ($a > 0) {
		echo '$a is positive.';
	} 
	else {
		echo '$a is negative';
	}
?>