<?php
require("dsadas6465564.php");
  $x=1+"0x10";
  echo "$x";
  
?>
