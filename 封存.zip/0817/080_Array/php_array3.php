<?php

$bloodType = array("A", "B", "AB", "O");

for ($i = 0; $i <= 3; $i++) {
	echo $bloodType[$i] . "<br />";
}

?>
