<?php

$a = array(0.1 => 'A', 0.9 => 'B', '1.1' => 'C');

var_dump($a);

?>
