<?php
header("Content-Type: image/png");

$filename = "cc.png";
$fileHandle = fopen($filename, "rb");
echo fread($fileHandle, filesize($filename));  //讀一筆資料 大小自訂
fclose($filename);

?>