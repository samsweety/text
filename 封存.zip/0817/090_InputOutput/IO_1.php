<?php

echo "Path and FileName:" . __FILE__ . "<br />";
echo "Path: " . dirname ( __FILE__ );
echo "Filename: " . basename ( __FILE__ ) . "<br />";
echo "Filesize: " . filesize ( __FILE__ )?>
