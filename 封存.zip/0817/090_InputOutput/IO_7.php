<?php
header("content-type: text/html; charset=utf-8");
 
$sData = "";
$f = fopen("data.txt", "r");
while (!feof($f))	// end of file
{
	$line = fgets($f);//取得單行資料
	$sData .= Trim($line) . "<br>";
}
fclose($f);
echo $sData;

?>
