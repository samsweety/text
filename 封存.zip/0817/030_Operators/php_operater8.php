<?php
  
    echo "flag 1<br>";
    @require("MyLibrary.php");//強制不顯示錯誤report
    echo "flag 2<br>";

?>