<?php
  $x = 1;
  $y = $x++;
  echo "x = $x, y = $y";
  
  echo "<br>";

  $x = 1;
  $y = ++$x;
  echo "x = $x, y = $y";
?>
