<?php
	$a = 100;
	$b = ($a > 0) ? "positive" : "negative";
	echo $b;
?>
