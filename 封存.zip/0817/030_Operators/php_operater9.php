<?php

$x = 100;
$y = &$x; //$y 會變成$x
$z=11;

$y = 200;
echo "x = $x </br>";

$y=&$z;
echo "y = $y </br>";

?>