<?php
	$a = 10; $b = 1;
	$a += $b;
	echo $a;
?>