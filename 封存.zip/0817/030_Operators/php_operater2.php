<?php
	$a = 1;
	$b = $a + 2;
	echo $b;
?>