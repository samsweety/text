<?php
	$a = "I love ";
	$b = &$a;
	$a="gigi";
	echo $a . $b;
?> 
