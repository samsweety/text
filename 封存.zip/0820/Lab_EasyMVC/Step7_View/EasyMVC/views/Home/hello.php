<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Lab</title>
</head>
<body>
    <H1>Hello! <?= $data->name ?></H1>
</body>
</html>
