<?php

$viewBag = new stdClass();
$viewBag->name = "Wolfgang Chien";

require_once("helloView.php");

?>