<link rel="stylesheet" href="js/jquery.mobile-1.3.2.min.css" />
<script src="js/jquery-1.9.1.min.js"></script>
<script src="js/jquery.mobile-1.3.2.min.js"></script>

<style>
.ui-table-columntoggle-btn {
	display: none;
}
</style>
