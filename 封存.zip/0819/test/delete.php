<?php
  if(!isset($_GET["id"])){
    die("404 ID not found");
  }
  $id=$_GET["id"];
  if(!is_numeric($id)){
    die("777 $id not a number");  
  }
  

  $sqlCommand=<<<here
    delete from employee where eId=$id;
    here;

  require("connect.php");
  mysqli_query($link,$sqlCommand);
  header("location:test.php");
?>