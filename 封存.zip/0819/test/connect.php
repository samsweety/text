<?php
    $link=mysqli_connect("localhost","root","root","db0819");
    mysqli_query($link,"set names utf-8");

?>