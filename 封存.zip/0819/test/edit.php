<?php
    if(!isset($_GET["id"])){
        die("404 ID not found");
    }
    $id=$_GET["id"];
    if(!is_numeric($id)){
        die("777 ID not a number");
    }
    
    $sqlCommand= <<<sql
        select * from employee where eId=$id;
        sql;
    require("connect.php");
    if(isset($_POST["submit"])){
        $firstName=$_POST["firstName"];
        $lastName=$_POST["lastName"];
        $cityId=$_POST["cityId"];
        $sql=<<<sql
            update employee set firstName='$firstName' , lastName='$lastName',cityId='$cityId' where eId=$id;
        sql;
        mysqli_query($link,$sql);
        header("location:test.php");
    }
    else{
        $result=mysqli_query($link,$sqlCommand);
        $row=mysqli_fetch_assoc($result);
    }
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <title>edit</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<form method="post">
  <div class="form-group row">
    <label for="firstName" class="col-4 col-form-label">first name</label> 
    <div class="col-8">
      <input id="firstName" name="firstName" type="text" class="form-control" value="<?= $row["firstName"]?>">
    </div>
  </div>
  <div class="form-group row">
    <label for="lastName" class="col-4 col-form-label">last name</label> 
    <div class="col-8">
      <input id="lastName" name="lastName" type="text" class="form-control" value="<?=$row["lastName"]?>">
    </div>
  </div>
  <div class="form-group row">
    <label class="col-4">city:</label> 
    <div class="col-8">
      <div class="custom-control custom-radio custom-control-inline">
        <input name="cityId" id="radiotext1_0" type="radio" class="custom-control-input" value="2"
        check=<?php ($row["cityId"]==2)?"checked":""?>> 
        <label for="radiotext1_0" class="custom-control-label">taipei</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="cityId" id="radiotext1_1" type="radio" class="custom-control-input" value="4"
        checked=<?php ($row["cityId"]==4)?"checked":""?>> 
        <label for="radiotext1_1" class="custom-control-label">taichung</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input name="cityId" id="radiotext1_2" type="radio" class="custom-control-input" value="6" 
        checked=<?php ($row["cityId"]==6)?"checked":""?>> 
        <label for="radiotext1_2" class="custom-control-label">Tainan</label>
      </div>
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
</form>
</div>

</body>
</html>

