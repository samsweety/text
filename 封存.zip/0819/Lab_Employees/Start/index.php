<?php
require_once("config.php");

$link=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname,3306) or die ( mysqli_connect_error() );
$result = mysqli_query ( $link, "set names utf8" );

$sqlCommand = <<<GGG
    select id,firstName,lastName,title,picture,
    (select count(*)from employee  where managerId=e.id) as count
    from employee as e
    GGG;

$result= mysqli_query ($link , $sqlCommand);

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lab</title>
<meta name="viewport" content="width=device-width,initial-scale=1" />
<script src="scripts/jquery-1.9.1.min.js"></script>
<script src="scripts/jquery.mobile-1.3.2.min.js"></script>
<link rel="stylesheet" href="scripts/jquery.mobile-1.3.2.min.css" />
<link rel="stylesheet" href="styles.css" />
</head>
<body>
<div data-role="page" data-theme="c">

<div data-role="header">
	<h1>Employee Details</h1>
</div>

<div data-role="content">

	<ul data-role="listview" data-filter="true">

        <?php for(;$row = mysqli_fetch_assoc($result);){ ?>
            <li>
            <a href="employeeDetails.php?id=1"> 
                <img src="images/<?=$row["picture"]?>">
                <h4><?= $row["firstName"]." ".$row["lastName"]?></h4>
                <p><?=$row["title"]?> </p> <span class="ui-li-count"><?=$row["count"]?></span>
            </a>
            </li>
		<?php } ?>

	</ul>
</div>

</div>
<?php
    mysqli_close($link);
?>
</body>

</html>